import tkinter as tk
from tkinter import messagebox
import os
import time

messagebox.showinfo("Warning", "Don't close the cmd or your computer/Avast can be corrupted.")
messagebox.showinfo("Warning", "If the cmd still opens, please don't close the program.")

def fake_error():
    messagebox.showerror("Runtime error", "Runtime error in <currentuser>")
def avast():
    program_name = "av.exe"  # Reemplaza con el nombre del programa que deseas abrir
    os.system(program_name)
time.sleep(5)
fake_error()
time.sleep(5)
avast()
time.sleep(5)
messagebox.showinfo("Warning", "Avast unistall is ready!")
